x = 1:1:36;
period = repmat(x',17,1);

data = readtable("final_data.csv");
data = [array2table(period),data];

writetable(data,'final_data_final.csv');

%% subdata 2
data = readtable("final_data_final.csv");
period = table2array(data(:,'period'));
region = table2array(data(:,'region'));
subdata = (period(:,1) <= 19) & ((region(:,1) ~= 1) & (region(:,1) ~= 8) & (region(:,1) ~= 14));
data = data(subdata,:);

writetable(data,'final_data_2.csv');

%% subdata 1
data = readtable("final_data_final.csv");
period = table2array(data(:,'period'));
subdata = (period(:,1) <= 16);
data = data(subdata,:);

writetable(data,'final_data_1.csv');

%% Graph
SU = table2array(data(:,'region'))==1;
DG = table2array(data(:,'region'))==3;
GB = table2array(data(:,'region'))==14;
BS = table2array(data(:,'region'))==2;
GJ = table2array(data(:,'region'))==6;
US = table2array(data(:,'region'))==7;
GW = table2array(data(:,'region'))==9;
CN = table2array(data(:,'region'))==11;
KN = table2array(data(:,'region'))==15;
reports_per = table2array(data(:,'reports_per'));
period = table2array(data(:,'period'));
plot(period(SU,1),reports_per(SU,1),period(DG,1),reports_per(DG,1),period(GB,1),reports_per(GB,1),period(BS,1),reports_per(BS,1),period(GJ,1),reports_per(GJ,1),period(US,1),reports_per(US,1))
legend 'SU' 'DG' 'GB' 'BS' 'GJ' 'US'

figure
plot(period(DG,1),reports_per(DG,1), ...
    period(BS,1),reports_per(BS,1), ...
    period(US,1),reports_per(US,1), ...
    period(GW,1),reports_per(GW,1), ...
    period(CN,1),reports_per(CN,1), ...
    period(KN,1),reports_per(KN,1))
legend 'DG' 'BS' 'US' 'GW' 'CN' 'KN'


%%






